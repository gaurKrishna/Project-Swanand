/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_Database;

/**
 *
 * @author dell
 */
//class for patient history
public class Patient_History {

	private String visitDate;
	private String present_Illness;
	private String Prescribedmedication;
	private int patientId;
	
	//constructor
	Patient_History(String visit_Date, String present_Illness, String medication, int patientId){
		
		this.visitDate = visit_Date;
		this.present_Illness = present_Illness;
		this.Prescribedmedication = medication;
		this.patientId = patientId;
	}

        public String getVisitDate() {
            return visitDate;
        }

        public String getPresent_Illness() {
            return present_Illness;
        }

        public String getPrescribedmedication() {
            return Prescribedmedication;
        }

        public int getPatientId() {
            return patientId;
        }

        public void setVisitDate(String visitDate) {
            this.visitDate = visitDate;
        }

        public void setPresent_Illness(String present_Illness) {
            this.present_Illness = present_Illness;
        }

        public void setPrescribedmedication(String Prescribedmedication) {
            this.Prescribedmedication = Prescribedmedication;
        }

        public void setPatientId(int patientId) {
            this.patientId = patientId;
        }
        
        

	void displayHistory(){
		System.out.println("Last visit date :- " + this.visitDate);
        System.out.println("Disease faced :- " + this.present_Illness);
        System.out.println("Medication provided :- " + this.Prescribedmedication);
	}
	
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_Database;

/**
 *
 * @author dell
 */
abstract class Staff extends User{
    protected int employee_id;
    protected String designation;
    protected int join_date;
    protected int join_month;
    protected int join_year;

    public void display_details()
    {
        System.out.println("Employee Id -" + employee_id);
        System.out.println("Designation -" + designation);
        System.out.println("Joining date -" + join_date + "/" + join_month + "/" + join_year);   
    }
}

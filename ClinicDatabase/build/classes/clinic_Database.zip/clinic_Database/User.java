/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinic_Database;

import java.sql.*;

/**
 *
 * @author dell
 */
//abstract parent class
abstract class User{

    protected String firstName;
    protected String middleName;
    protected String lastName;
    protected String gender;
    protected long phoneNo;
    protected int birthDate;
    protected int birthMonth;
    protected int birthYear;
    
    //nested class for storing various fields of address
    protected class Address{

        String houseNo;
        String society;
        String landmark;
        String city;
        String state;
        int pincode;

        public void setAddress(String houseNo, String society, String landmark, String city, String state, int pincode)
        {
            this.houseNo = houseNo;
            this.society = society;
            this.landmark = landmark;
            this.city = city;
            this.state =state;
            this.pincode = pincode;
        }
        
        //method for displaying address
        public void display_address(){

            System.out.println("ADDRESS");
            System.out.println("HOUSE NO. : " + houseNo);
            System.out.println("SOCIETY/COLONY : " + society);

            //if landmark field is left empty
            if(landmark == "")
                System.out.println("LANDMARK : - ");
            else
                System.out.println("LANDMARK : " + landmark);
                
            System.out.println("CITY : " + city);
            System.out.println("STATE : " + state);
            System.out.println("PINCODE : " + pincode);
        }
    }
    
    abstract public void addAdressTable(int UserID) throws SQLException;
    
//    abstract public void display_details();
}